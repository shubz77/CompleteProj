package com.manage.OIMS.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.manage.OIMS.dao.PolicyTypeDao;
import com.manage.OIMS.model.PolicyType;

class PolicyTypeServiceImplTest {

	@Mock
	PolicyTypeDao policytypeDao;

	@InjectMocks
	PolicyTypeServiceImpl policytypeServiceImpl;

	@BeforeEach
	public void setUpBeforeClass() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	// Method to Test updatePolicyType
	@Test
	public void testUpdatePolicyType() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeServiceImpl.updatePolicyType(policytype)).thenReturn(1);
		int policytype1 = policytypeServiceImpl.updatePolicyType(policytype);
		assertEquals(policytype1, 1);
	}

	// Method to Test AddPolicyType
	@Test
	public void testAddPolicyType() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeServiceImpl.addPolicyType(policytype)).thenReturn(policytype);
		PolicyType policytype2 = policytypeServiceImpl.addPolicyType(policytype);
		assertEquals(policytype2.getPolicyTypeName(), "party");
	}

	// Method to Test deletePolicyType
	@Test
	public void testDeletePolicyType() {
		when(policytypeServiceImpl.deletePolicyType(1)).thenReturn(1);
		int policytype8 = policytypeServiceImpl.deletePolicyType(1);
		assertEquals(policytype8, 1);

	}

	// Method to Test GetPolicyTypesByPolicyId
	@Test
	public void testGetPolicyTypesByPolicyId() {
		List<PolicyType> policytype = new ArrayList<>();
		policytype.add(new PolicyType(1, "party", 1500, 2));
		when(policytypeServiceImpl.getPolicyTypesByPolicyId(2)).thenReturn(policytype);
		assertEquals(policytypeServiceImpl.getPolicyTypesByPolicyId(2).size(), 1);

	}

	// Method to Test GetByNameAndPolicyId
	@Test
	public void testGetByNameAndPolicyId() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeServiceImpl.getByNameAndPolicyId("party", 2)).thenReturn(policytype);
		PolicyType policytype5 = policytypeServiceImpl.getByNameAndPolicyId("party", 2);
		assertEquals(policytype5.getPolicyTypeCost(), 1500);

	}

	// Method to Test GetPolicyType
	@Test
	public void testGetPolicyType() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeServiceImpl.getPolicyType(1)).thenReturn(policytype);
		PolicyType policytype6 = policytypeServiceImpl.getPolicyType(1);
		assertEquals(policytype6.getPolicyTypeName(), "party");
	}
}
