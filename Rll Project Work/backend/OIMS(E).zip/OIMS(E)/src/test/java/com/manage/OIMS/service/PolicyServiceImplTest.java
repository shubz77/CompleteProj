package com.manage.OIMS.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

//import com.manage.OIMS.dao.EquipmentDao;
import com.manage.OIMS.dao.PolicyTypeDao;

import com.manage.OIMS.dao.PolicyDao;
import com.manage.OIMS.model.Policy;

class PolicyServiceImplTest {

	@Mock
	PolicyDao policyDao;

	@Mock
	PolicyTypeDao policytypeDao;;


	

	@InjectMocks
	PolicyServiceImpl service;

	@BeforeEach
	public void setUpBeforeClass() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	// Method to Test getPolicysByOrganizerId
	@Test
	public void testGetPolicysByOrganizerId() {

		int orgId = 100;
		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(100, "Sai", "Shirdi", "987654", 1000));

		when(service.getPolicysByOrganizerId(orgId)).thenReturn(policys);
		assertEquals(service.getPolicysByOrganizerId(orgId).size(), 1);
	}

	// Method to Test getgetPolicyOfPlace
	@Test
	public void testGetPolicyOfPlace() {

		String place = "Shirdi";
		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(107, "Sai", "Shirdi", "987654", 1015));

		when(service.getPolicyOfPlace(place)).thenReturn(policys);
		assertEquals(service.getPolicyOfPlace(place).size(), 1);
	}

	// Method to Test AddPolicy
	@Test
	public void testAddPolicy() {

		Policy policy = new Policy(101, "Sai", "Shirdi", "987654", 1010);
		when(service.addPolicy(policy)).thenReturn(policy);
		Policy a = service.addPolicy(policy);
		assertEquals(a.getPolicyName(), "Sai");
	}

	// Method to Test GetPolicybyId
	@Test
	public void testGetPolicybyId() {

		int PolicyId = 106;
		Policy policy = new Policy(106, "Sai", "Shirdi", "987654", 1015);
		when(service.getPolicy(PolicyId)).thenReturn(policy);
		assertEquals(service.getPolicy(PolicyId), policy);
	}

	// Method to Test GetPolicys
	@Test
	public void testGetPolicys() {

		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(102, "Sai", "Shirdi", "987654", 1011));
		policys.add(new Policy(103, "Balaji", "Nagpur", "987654", 1012));

		when(service.getPolicys()).thenReturn(policys);
		assertEquals(service.getPolicys().size(), 2);
	}

	// Method to Test UpdatePolicy
	@Test
	public void testUpdatePolicy() {

		Policy policy1 = new Policy(104, "Sai", "Shirdi", "987654", 1013);
		when(service.updatePolicy(policy1)).thenReturn(1);
		assertEquals(service.updatePolicy(policy1), 1);
	}

	// Method to Test DeletePolicy
	@Test
	public void testDeletePolicy() {

		
		when(policytypeDao.deletePolicyTypeByPolicyId(1)).thenReturn(1);
		//when(equipmentDao.deleteEquipmentByPolicyId(1)).thenReturn(1);

		int policyId = 105;
		when(service.deletePolicy(policyId)).thenReturn(1);
		assertEquals(service.deletePolicy(policyId), 1);

	}
}