package com.manage.OIMS.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.manage.OIMS.model.PolicyType;
import com.manage.OIMS.service.PolicyTypeService;

@RunWith(JUnitPlatform.class)
class PolicyTypeControllerTest {

	@Mock
	private PolicyTypeService policytypeService;

	@InjectMocks
	private PolicyTypeController policytypeController;

	@BeforeEach
	public void setUpBeforeClass() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testAddPolicyType() throws Exception {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeService.addPolicyType(policytype)).thenReturn(policytype);
		PolicyType policytype2 = policytypeController.addPolicyType(policytype);
		assertEquals(policytype2.getPolicyTypeName(), "party");

	}

	// Testing.. deletePolicyType Method
	@Test
	public void testDeletePolicyType() throws Exception {
		when(policytypeService.deletePolicyType(1)).thenReturn(1);
		int policytype8 = policytypeController.deletePolicyType(1);
		assertEquals(policytype8, 1);
	}

	// Testing.. updatePolicyType Method
	@Test
	public void testUpdatePolicyType() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeService.updatePolicyType(policytype)).thenReturn(1);
		int policytype1 = policytypeController.updatePolicyType(policytype);
		assertEquals(policytype1, 1);
	}

	// Testing.. getPolicyTypesByPolicyId Method
	@Test
	public void testgetPolicyTypesByPolicyId() {
		List<PolicyType> policytype = new ArrayList<>();
		policytype.add(new PolicyType(1, "party", 1500, 2));
		when(policytypeService.getPolicyTypesByPolicyId(2)).thenReturn(policytype);
		assertEquals(policytypeController.getPolicyTypesByPolicyId(2).size(), 1);

	}

	// Testing.. getByNameAndPolicyId Method
	@Test
	public void testgetByNameAndPolicyId() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeService.getByNameAndPolicyId("party", 2)).thenReturn(policytype);
		PolicyType policytype5 = policytypeController.getByNameAndPolicyId("party", 2);
		assertEquals(policytype5.getPolicyTypeCost(), 1500);

	}

	// Testing.. getPolicyType Method
	@Test
	public void testgetPolicyType() {
		PolicyType policytype = new PolicyType(1, "party", 1500, 2);
		when(policytypeService.getPolicyType(1)).thenReturn(policytype);
		PolicyType policytype6 = policytypeController.getPolicyType(1);
		assertEquals(policytype6.getPolicyTypeName(), "party");
	}

}