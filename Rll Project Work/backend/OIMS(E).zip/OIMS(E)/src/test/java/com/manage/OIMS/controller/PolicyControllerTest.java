package com.manage.OIMS.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.manage.OIMS.model.Policy;
import com.manage.OIMS.service.NotificationService;
import com.manage.OIMS.service.PolicyService;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
class PolicyControllerTest {

	@Mock
	private PolicyService service;

	@Mock
	private NotificationService notiService;

	@InjectMocks
	private PolicyController controller;

	// Testing... getPolicysByOrganizerId Handler
	@Test
	public void testGetPolicysByOrganizerId() {

		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(100, "Sai", "Shirdi", "987654", 1000));

		when(service.getPolicysByOrganizerId(2)).thenReturn(policys);
		assertEquals(controller.getPolicysByOrganizerId(2), policys);
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... getAllDistinctPlaces Handler
	@Test
	public void testGetAllDistinctPlaces() {

		List<String> places = new ArrayList<>();
		places.add("Pune");
		places.add("Mumbai");

		when(service.getAllDistinctPlaces()).thenReturn(places);
		assertEquals(places, controller.getAllDistinctPlaces());
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... getPolicyOfPlace Handler
	@Test
	public void testGetPolicyOfPlace() {

		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(100, "Sai", "Shirdi", "987654", 1000));

		when(service.getPolicyOfPlace("Shirdi")).thenReturn(policys);
		assertEquals(policys, controller.getPolicyOfPlace("Shirdi"));
	}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... addPolicy Handler
	@Test
	public void testAddPolicy() {

		Policy policy = new Policy(100, "Sai", "Shirdi", "987654", 1000);

		when(service.addPolicy(policy)).thenReturn(policy);
		assertEquals(policy, controller.addPolicy(policy));
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... getPolicy Handler
	@Test
	public void testGetPolicy() {
		Policy policy = new Policy(100, "Sai", "Shirdi", "987654", 1000);
		when(service.getPolicy(100)).thenReturn(policy);
		assertEquals(policy, controller.getPolicy(100));
	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... getPolicys Handler
	@Test
	public void testGetPolicys() {
		List<Policy> policys = new ArrayList<>();
		policys.add(new Policy(100, "Sai", "Shirdi", "987654", 1000));
		when(service.getPolicys()).thenReturn(policys);
		assertEquals(policys, controller.getPolicys());
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Testing... updatePolicy Handler
	@Test
	public void testUpdatePolicy() {
		Policy policy = new Policy(100, "Sai", "Shirdi", "987654", 1000);
		when(service.updatePolicy(policy)).thenReturn(1);
		assertEquals(1, controller.updatePolicy(policy));
	}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Testing... deletePolicy Handler
	@Test
	public void testDeletePolicy() {
		when(service.deletePolicy(100)).thenReturn(1);
		assertEquals(1, controller.deletePolicy(100));
	}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
