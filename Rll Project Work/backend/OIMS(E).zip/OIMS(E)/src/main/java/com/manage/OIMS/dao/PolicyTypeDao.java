package com.manage.OIMS.dao;

import java.util.List;

import com.manage.OIMS.model.PolicyType;

public interface PolicyTypeDao {
	
    public PolicyType addPolicyType(PolicyType policytype);
	
	public int updatePolicyType(PolicyType policytype);
	
	public PolicyType getPolicyType(int policytypeId);
	
	public int deletePolicyType(int policytypeId);

	public List<PolicyType> getPolicyTypesByPolicyId(int policytypeId);

	public PolicyType getByNameAndPolicyId(String eName, int vId);

	public int deletePolicyTypeByPolicyId(int policyId);

}
