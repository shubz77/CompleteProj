package com.manage.OIMS.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class TablesDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public String createAllTables() {
		String query1 = "CREATE TABLE IF NOT EXISTS member("
				+ "member_id INT  NOT NULL  AUTO_INCREMENT,"
				+ "role  VARCHAR(50)  NOT NULL,"
				+ "first_name VARCHAR(50) NOT NULL,"
				+ "last_name VARCHAR(50) NOT NULL,"
				+ "email VARCHAR(50) NOT NULL UNIQUE,"
				+ "phone_number VARCHAR(50) NOT NULL UNIQUE,"
				+ "password VARCHAR(50) NOT NULL,"
				+ "PRIMARY KEY (member_id))";

				      
		
		 String query2 ="CREATE TABLE IF NOT EXISTS policy("
				+ "policy_id INT NOT NULL AUTO_INCREMENT,"
				+ "policy_name VARCHAR(50)  NOT NULL,"
				+ "policy_place VARCHAR(50) NOT NULL,"
				+ "policy_contact VARCHAR(50) NOT NULL,"
				+ "member_id INT NOT NULL ,"
				+ "PRIMARY KEY (policy_id),"
				+ "FOREIGN KEY (member_id) REFERENCES member(member_id));";
		 
		        
				
		 String query3 ="CREATE TABLE IF NOT EXISTS policytype("
                + "policytype_id  INT  NOT NULL  AUTO_INCREMENT,"
                + "policytype_name  VARCHAR(50)  NOT NULL,"
                + "policytype_cost INT NOT NULL,"
                + "policy_id INT NOT NULL,"
                + "PRIMARY KEY (policytype_id),"
                + "FOREIGN KEY (policy_id) REFERENCES policy(policy_id));";
                
                
                
                 
                 
                 String query6 ="CREATE TABLE IF NOT EXISTS notification("
                 + "notification_id  INT  NOT NULL  AUTO_INCREMENT,"
                 + "time VARCHAR(50) NOT NULL,"
                 + "date VARCHAR(50) NOT NULL,"
                 + "message VARCHAR(255) NOT NULL,"
                 + "member_id  INT  NOT NULL,"
                 + "PRIMARY KEY (notification_id),"
                 + "FOREIGN KEY (member_id) REFERENCES member(member_id));";
                 
             
                 String query7 ="CREATE TABLE IF NOT EXISTS booking("
                 + "booking_id  INT  NOT NULL  AUTO_INCREMENT,"
                 + "date DATE NOT NULL,"
                 + "policy_count INT NOT NULL,"
                 + "policytype_name VARCHAR(50) NOT NULL,"
                 
                 + "policytype_cost INT NOT NULL,"
                 + "misc_cost INT NOT NULL,"
                 + "other_cost INT NOT NULL,"
                 + "total_cost INT NOT NULL,"
                 + "payment_status VARCHAR(50) NOT NULL,"
                 + "member_id INT NOT NULL,"
                 + "policy_id INT NOT NULL,"
                 + "del_status INT ,"
                 + "PRIMARY KEY (booking_id),"
                 + "FOREIGN KEY (member_id) REFERENCES member(member_id),"
                 + "FOREIGN KEY (policy_id) REFERENCES policy(policy_id))";
                 
               

                this.jdbcTemplate.update(query1); 
                this.jdbcTemplate.update(query2); 
                this.jdbcTemplate.update(query3); 
               
                this.jdbcTemplate.update(query6); 
                this.jdbcTemplate.update(query7);

                return "Tables Created...";
	}

}
