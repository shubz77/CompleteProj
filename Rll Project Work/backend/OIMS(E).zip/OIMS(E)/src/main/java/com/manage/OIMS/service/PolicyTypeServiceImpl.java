package com.manage.OIMS.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.manage.OIMS.dao.PolicyTypeDao;
import com.manage.OIMS.model.PolicyType;

@org.springframework.stereotype.Service
public class PolicyTypeServiceImpl implements PolicyTypeService {

	@Autowired
	PolicyTypeDao policytypeDao;

	// Get policytype list by policy Id
	@Override
	public List<PolicyType> getPolicyTypesByPolicyId(int policyId) {
		return policytypeDao.getPolicyTypesByPolicyId(policyId);
	}

	// Add PolicyType
	@Override
	public PolicyType addPolicyType(PolicyType policytype) {
		return this.policytypeDao.addPolicyType(policytype);
	}

	// Get policytype list by Name and Policy Id
	@Override
	public PolicyType getByNameAndPolicyId(String EName, int VId) {
		return this.policytypeDao.getByNameAndPolicyId(EName, VId);

	}

	// Get policytype By Id
	@Override
	public PolicyType getPolicyType(int policytypeId) {
		return policytypeDao.getPolicyType(policytypeId);
	}

	// Update PolicyType
	@Override
	public int updatePolicyType(PolicyType policytype) {
		return policytypeDao.updatePolicyType(policytype);
	}

	// Delete PolicyType
	@Override
	public int deletePolicyType(int policytypeId) {
		return policytypeDao.deletePolicyType(policytypeId);
	}

}
