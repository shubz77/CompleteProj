package com.manage.OIMS.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.manage.OIMS.model.BookingDetail;

public class BookingDetailRowMapper implements RowMapper<BookingDetail> {
	

@Override
public BookingDetail mapRow(ResultSet rs, int rowNum) throws SQLException {
		  
		  
		  BookingDetail bookingDetail = new BookingDetail();
		  
		  bookingDetail.setMemberId(rs.getInt("member_id"));
	      bookingDetail.setPolicyId(rs.getInt("policy_id"));
		  
		  bookingDetail.setBookingId(rs.getInt("booking_id"));
	      bookingDetail.setDate(rs.getDate("date"));
	      bookingDetail.setGuestCount(rs.getInt("policy_count"));
	      bookingDetail.setPolicyTypeName(rs.getString("policytype_name"));
	      
	      bookingDetail.setPolicyTypeCost(rs.getInt("policytype_cost"));
	      bookingDetail.setEquipmentCost(rs.getInt("misc_cost"));
	      bookingDetail.setFoodItemCost(rs.getInt("other_cost"));
	      bookingDetail.setTotalCost(rs.getInt("total_cost"));
	      bookingDetail.setPaymentStatus(rs.getString("payment_status"));
	     
			
			bookingDetail.setFirstName(rs.getString("first_name"));
			bookingDetail.setLastName(rs.getString("last_name"));
			bookingDetail.setEmail(rs.getString("email"));
			bookingDetail.setPhoneNumber(rs.getString("phone_number"));
			
			
			bookingDetail.setPolicyName(rs.getString("policy_name"));
			bookingDetail.setPolicyPlace(rs.getString("policy_place"));
			bookingDetail.setPolicyContact(rs.getString("policy_contact"));
			bookingDetail.setDelStatus(rs.getInt("del_status"));
			
			
	      return bookingDetail;
	      
	
};
	
}
