package com.manage.OIMS.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.manage.OIMS.dao.PolicyTypeDao;

import com.manage.OIMS.dao.PolicyDao;
import com.manage.OIMS.model.Policy;

@org.springframework.stereotype.Service
public class PolicyServiceImpl implements PolicyService {

	@Autowired
	PolicyDao policyDao;
	
	
	
	
	@Autowired
	PolicyTypeDao policytypeDao;

	@Override
	public List<Policy> getPolicysByOrganizerId(int orgId) {
		return policyDao.getPolicyByOrganizerId(orgId);
	}

	// Get Distinct Places
	@Override
	public List<String> getAllDistinctPlaces() {
		return policyDao.getAllDistinctPlaces();
	}

	// Policys by Place
	@Override
	public List<Policy> getPolicyOfPlace(String place) {
		return policyDao.getPolicyOfPlace(place);
	}

	// Add Policy
	@Override
	public Policy addPolicy(Policy policy) {
		return this.policyDao.addPolicy(policy);
	}

	// Get Policy by Id
	@Override
	public Policy getPolicy(int policyId) {
		return policyDao.getPolicy(policyId);
	}

	// List all policys
	@Override
	public List<Policy> getPolicys() {
		return policyDao.getPolicys();
	}

	// Update..
	@Override
	public int updatePolicy(Policy policy) {
		return policyDao.updatePolicy(policy);
	}

	// Delete...
	@Override
	public int deletePolicy(int policyId) {
		
		policytypeDao.deletePolicyTypeByPolicyId(policyId);
		
		return policyDao.deletePolicy(policyId);
	}
	
	
	

}
