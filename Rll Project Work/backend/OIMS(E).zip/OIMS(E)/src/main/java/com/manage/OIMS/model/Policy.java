package com.manage.OIMS.model;

public class Policy {
	
	private int policyId;
	private String policyName;
	private String policyPlace;
	private String policyContact;
	private int memberId;
	
	
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Policy(int policyId, String policyName, String policyPlace, String policyContact, int memberId) {
		super();
		this.policyId = policyId;
		this.policyName = policyName;
		this.policyPlace = policyPlace;
		this.policyContact = policyContact;
		this.memberId = memberId;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyPlace() {
		return policyPlace;
	}
	public void setPolicyPlace(String policyPlace) {
		this.policyPlace = policyPlace;
	}
	public String getPolicyContact() {
		return policyContact;
	}
	public void setPolicyContact(String policyContact) {
		this.policyContact = policyContact;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	
	
	@Override
	public String toString() {
		return "Policy [policyId=" + policyId + ", policyName=" + policyName + ", policyPlace=" + policyPlace
				+ ", policyContact=" + policyContact + ", memberId=" + memberId + "]";
	}
	
	
	
	

}
