package com.manage.OIMS.dao;

import java.util.List;

import com.manage.OIMS.model.Policy;

public interface PolicyDao {

	public List<Policy> getPolicyByOrganizerId(int orgId);
	
    public Policy addPolicy(Policy policy);
	
	public int updatePolicy(Policy policy);
	
	public Policy getPolicy(int policyId);
	
	public List<Policy> getPolicys();
	
	public int deletePolicy(int policyId);

	public List<String> getAllDistinctPlaces();
	
	public List<Policy> getPolicyOfPlace(String place);
	
	

}
