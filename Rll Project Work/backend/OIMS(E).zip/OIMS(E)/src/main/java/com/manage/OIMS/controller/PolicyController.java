package com.manage.OIMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manage.OIMS.model.Policy;
import com.manage.OIMS.service.NotificationService;
import com.manage.OIMS.service.PolicyService;

@RestController
@RequestMapping("/policy")
@CrossOrigin("*")
public class PolicyController {

	@Autowired
	PolicyService policyService;

	@Autowired
	NotificationService notificationService;

	/// handler to get All policys by organizer Id
	@GetMapping("/organizer/{orgId}")
	public List<Policy> getPolicysByOrganizerId(@PathVariable("orgId") int orgId) {
		return policyService.getPolicysByOrganizerId(orgId);
	}

	/// handler to get All distinct places
	@GetMapping("/places")
	public List<String> getAllDistinctPlaces() {
		return policyService.getAllDistinctPlaces();
	}

	// handler to get policy for selected place
	@GetMapping("/getPolicys/{place}")
	List<Policy> getPolicyOfPlace(@PathVariable("place") String place) {
		return policyService.getPolicyOfPlace(place);
	}

	// Add Policy Request Handler
	@PostMapping("/add")
	public Policy addPolicy(@RequestBody Policy policy) {
		this.notificationService.notifyOnPolicyAdd(policy);
		return this.policyService.addPolicy(policy);
	}

	// Get policy by policy Id
	@GetMapping("/getPolicy/{policyId}")
	public Policy getPolicy(@PathVariable("policyId") int policyId) {
		return policyService.getPolicy(policyId);
	}

	// List of policys
	@GetMapping("/getPolicys")
	public List<Policy> getPolicys() {
		return policyService.getPolicys();
	}

	// Update Policy
	@PutMapping("/updatePolicy")
	public int updatePolicy(@RequestBody Policy policy) {
		return policyService.updatePolicy(policy);
	}

	// Delete Policy
	@DeleteMapping("/deletePolicy/{policyId}")
	public int deletePolicy(@PathVariable("policyId") int policyId) {
		
		return policyService.deletePolicy(policyId);
	}
	

}
