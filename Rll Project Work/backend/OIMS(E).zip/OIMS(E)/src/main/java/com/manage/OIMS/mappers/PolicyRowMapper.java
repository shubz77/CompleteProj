package com.manage.OIMS.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.manage.OIMS.model.Policy;

@Service
public class PolicyRowMapper implements RowMapper<Policy> {

	@Override
	public Policy mapRow(ResultSet rs, int rowNum) throws SQLException {
		
Policy policy = new Policy();
		
		policy.setPolicyId(rs.getInt("policy_id"));
		policy.setPolicyName(rs.getString("policy_name"));
		policy.setPolicyPlace(rs.getString("policy_place"));
		policy.setPolicyContact(rs.getString("policy_contact"));
		policy.setMemberId(rs.getInt("member_id"));
			
		return policy;
	}

}
