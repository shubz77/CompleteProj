package com.manage.OIMS.service;

import java.util.List;

import com.manage.OIMS.model.Policy;

public interface PolicyService {

	public List<Policy> getPolicysByOrganizerId(int orgId);

	public List<String> getAllDistinctPlaces();

	public List<Policy> getPolicyOfPlace(String place);

	public Policy addPolicy(Policy policy);

	public Policy getPolicy(int policyId);

	public List<Policy> getPolicys();

	public int updatePolicy(Policy policy);

	public int deletePolicy(int policyId);

}
