package com.manage.OIMS.model;

import java.sql.Date;


public class Booking {
	
	private int bookingId;
	private Date date;
	private int guestCount;
	private String policytypeName;
	private String equipmentName;
	private String foodItemName;
	private int policytypeCost;
	private int equipmentCost;
	private int foodItemCost;
	private int totalCost;
	private String paymentStatus;
	private int memberId;
	private int policyId;
	private String selectedFoodItems;
	private String selectedEquipments;
	private int delStatus ;
	
	
	public Booking() {
		super();
	}

	public Booking(int bookingId, Date date, int guestCount, String policytypeName, String equipmentName,
			String foodItemName, int policytypeCost, int equipmentCost, int foodItemCost, int totalCost,
			String paymentStatus, int memberId, int policyId, String selectedFoodItems, String selectedEquipments) {
		super();
		this.bookingId = bookingId;
		this.date = date;
		this.guestCount = guestCount;
		this.policytypeName = policytypeName;
		this.equipmentName = equipmentName;
		this.foodItemName = foodItemName;
		this.policytypeCost = policytypeCost;
		this.equipmentCost = equipmentCost;
		this.foodItemCost = foodItemCost;
		this.totalCost = totalCost;
		this.paymentStatus = paymentStatus;
		this.memberId = memberId;
		this.policyId = policyId;
		this.selectedFoodItems = selectedFoodItems;
		this.selectedEquipments = selectedEquipments;
	}
	
	public int getDelStatus() {
		return delStatus;
	}
	public void setDelStatus(int delStatus) {
		this.delStatus = delStatus;
	}
	public int getBookingId(){
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getGuestCount() {
		return guestCount;
	}
	public void setGuestCount(int guestCount) {
		this.guestCount = guestCount;
	}
	public String getPolicyTypeName() {
		return policytypeName;
	}
	public void setPolicyTypeName(String policytypeName) {
		this.policytypeName = policytypeName;
	}
	public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public String getFoodItemName() {
		return foodItemName;
	}
	public void setFoodItemName(String foodItemName) {
		this.foodItemName = foodItemName;
	}
	public int getPolicyTypeCost() {
		return policytypeCost;
	}
	public void setPolicyTypeCost(int policytypeCost) {
		this.policytypeCost = policytypeCost;
	}
	public int getEquipmentCost() {
		return equipmentCost;
	}
	public void setEquipmentCost(int equipmentCost) {
		this.equipmentCost = equipmentCost;
	}
	public int getFoodItemCost() {
		return foodItemCost;
	}
	public void setFoodItemCost(int foodItemCost) {
		this.foodItemCost = foodItemCost;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public String getSelectedFoodItems() {
		return selectedFoodItems;
	}
	public void setSelectedFoodItems(String selectedFoodItems) {
		this.selectedFoodItems = selectedFoodItems;
	}
	public String getSelectedEquipments() {
		return selectedEquipments;
	}
	public void setSelectedEquipments(String selectedEquipments) {
		this.selectedEquipments = selectedEquipments;
	}
	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", date=" + date + ", guestCount=" + guestCount + ", policytypeName="
				+ policytypeName + ", equipmentName=" + equipmentName + ", foodItemName=" + foodItemName + ", policytypeCost="
				+ policytypeCost + ", equipmentCost=" + equipmentCost + ", foodItemCost=" + foodItemCost + ", totalCost=" + totalCost
				+ ", paymentStatus=" + paymentStatus + ", memberId=" + memberId + ", policyId=" + policyId
				+ ", selectedFoodItems=" + selectedFoodItems + ", selectedEquipments=" + selectedEquipments + "]";
	}
	
	
	
	
}
