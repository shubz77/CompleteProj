package com.manage.OIMS.model;

public class PolicyType {
	
	private int policytypeId;
	private String policytypeName;
	private int policytypeCost;
	private int policyId;
	
	
	
	public PolicyType(int policytypeId, String policytypeName, int policytypeCost, int policyId) {
		super();
		this.policytypeId = policytypeId;
		this.policytypeName = policytypeName;
		this.policytypeCost = policytypeCost;
		this.policyId = policyId;
	}
	public PolicyType() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getPolicyTypeId() {
		return policytypeId;
	}
	public void setPolicyTypeId(int policytypeId) {
		this.policytypeId = policytypeId;
	}
	public String getPolicyTypeName() {
		return policytypeName;
	}
	public void setPolicyTypeName(String policytypeName) {
		this.policytypeName = policytypeName;
	}
	public int getPolicyTypeCost() {
		return policytypeCost;
	}
	public void setPolicyTypeCost(int policytypeCost) {
		this.policytypeCost = policytypeCost;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	
	
	@Override
	public String toString() {
		return "PolicyType [policytypeId=" + policytypeId + ", policytypeName=" + policytypeName + ", policytypeCost=" + policytypeCost + ", policyId="
				+ policyId + "]";
	}
	
	
	
	

}
