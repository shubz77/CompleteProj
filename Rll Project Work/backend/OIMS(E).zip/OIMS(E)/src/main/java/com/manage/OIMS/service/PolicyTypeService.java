package com.manage.OIMS.service;

import java.util.List;

import com.manage.OIMS.model.PolicyType;

public interface PolicyTypeService {

	public List<PolicyType> getPolicyTypesByPolicyId(int policytypeId);

	public PolicyType addPolicyType(PolicyType policytype);

	public PolicyType getByNameAndPolicyId(String EName, int VId);

	public PolicyType getPolicyType(int policytypeId);

	public int updatePolicyType(PolicyType policytype);

	public int deletePolicyType(int policytypeId);
	
}
