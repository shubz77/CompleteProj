package com.manage.OIMS.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.manage.OIMS.model.PolicyType;
import com.manage.OIMS.service.PolicyTypeService;

@RestController
@RequestMapping("/policytype")
@CrossOrigin("*")
public class PolicyTypeController {
	
	@Autowired
	PolicyTypeService policytypeService;
	
	// Get List of policytypes by policyId
	@GetMapping("/getPolicyTypes/{policyId}")
    public List<PolicyType> getPolicyTypesByPolicyId(@PathVariable("policyId") int policytypeId) {
    	 return policytypeService.getPolicyTypesByPolicyId(policytypeId);
    }
	
	// Add policytype
	@PostMapping("/add")
	public PolicyType addPolicyType(@RequestBody PolicyType policytype) {
		return this.policytypeService.addPolicyType(policytype);
	}
	
	// Get policytype by Name and PolicyId 
	@GetMapping("/getOne/{policytypeName}/{policyId}")
	public PolicyType getByNameAndPolicyId(@PathVariable("policytypeName") String EName,@PathVariable("policyId") int VId) {
		return this.policytypeService.getByNameAndPolicyId(EName,VId);
	}
	
	// Get policytype 
	@GetMapping("/getPolicyType/{policytypeId}")
    public PolicyType getPolicyType(@PathVariable("policytypeId") int policytypeId) {
    	 return policytypeService.getPolicyType(policytypeId);
    }
    
    //Update policytype
    @PutMapping("/updatePolicyType")
    public int updatePolicyType(@RequestBody PolicyType policytype) {
   	 return policytypeService.updatePolicyType(policytype);
   }
    
    //Delete policytype
    @DeleteMapping("/deletePolicyType/{policytypeId}")
    public int deletePolicyType(@PathVariable("policytypeId") int policytypeId) {
    	return policytypeService.deletePolicyType(policytypeId);
      }


}
