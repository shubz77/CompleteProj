package com.manage.OIMS.service;

import java.time.LocalDate;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import com.manage.OIMS.dao.BookingDao;
import com.manage.OIMS.dao.MemberDao;
import com.manage.OIMS.dao.NotificationDao;
import com.manage.OIMS.model.Booking;
import com.manage.OIMS.model.BookingDetail;
import com.manage.OIMS.model.Member;
import com.manage.OIMS.model.Notification;
import com.manage.OIMS.model.Policy;

@org.springframework.stereotype.Service
public class NotificationServiceImpl implements NotificationService {

	@Autowired
	Notification notification;

	@Autowired
	MemberDao memberDao;

	@Autowired
	NotificationDao notificationDao;

	@Autowired
	BookingDao bookingDao;

	// Generate Notification On Registration//##
	@Override
	public int notificationOnRegistration(Member member) {
		Member newMember = memberDao.getMember(member.getEmail());

		this.notification.setMemberId(newMember.getMemberId());
		LocalDate localDate = LocalDate.now();
		String localTime = LocalTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_TIME);
		this.notification.setDate(localDate.toString());
		this.notification.setTime(localTime);
		if (newMember.getRole().equals("user")) {
			String userNoti = "Welcome " + newMember.getFirstName()
					+ ", You have successfully registered on Insurance Management System. "
					+ "Now you can book your policies on various schemes.";
			this.notification.setMessage(userNoti);
		} else {
			String orgNoti = "Welcome " + member.getFirstName()
					+ ", You have successfully registered on Insurance Management System. "
					+ "Now you can add your policy on the portal";
			this.notification.setMessage(orgNoti);
		}

		return notificationDao.addNotification(notification);
	}

	// Generate notification On Booking//##
	@Override
	public int notifyOnBooking(Booking booking) {
		Notification notification = new Notification();

		notification.setMemberId(booking.getMemberId());
		LocalDate localDate = LocalDate.now();
		String localTime = LocalTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_TIME);

		notification.setDate(localDate.toString());
		notification.setTime(localTime);

		String userNoti = "Dear User, Your booking data is stored temprory, Please make it fixed by completing payment";

		notification.setMessage(userNoti);
		notificationDao.addNotification(notification);
		return 1;

	}

	// Generate notification On payment//##
	@Override
	public int notifyOnPayment(int bookingId) {

		BookingDetail singleBooking = this.bookingDao.getSingleBooking(bookingId);

		int memberId = memberDao.getMemberIdByPolicyId(singleBooking.getPolicyId());

		Member member = memberDao.getMember(memberId);

		String userNoti = "Dear " + singleBooking.getFirstName() + ", Your payment of Rs. "
				+ singleBooking.getTotalCost() + " for booking ID " + singleBooking.getBookingId()
				+ " is processed successfully." + "Your " + singleBooking.getPolicyTypeName()
				+ " policy is booked on policy Name " + singleBooking.getPolicyName() + " at "
				+ singleBooking.getPolicyPlace() + " on date " + singleBooking.getDate();

		String orgNoti = "Dear " + member.getFirstName() + ", Your Policy " + singleBooking.getPolicyName()
				+ " is booked by user " + singleBooking.getFirstName() + " " + singleBooking.getLastName()
				+ " for an type of " + singleBooking.getPolicyTypeName() + " on date " + singleBooking.getDate();

		Notification notification = new Notification();
		notification.setMemberId(singleBooking.getMemberId());
		LocalDate localDate = LocalDate.now();
		String localTime = LocalTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_TIME);

		notification.setDate(localDate.toString());
		notification.setTime(localTime);
		notification.setMessage(userNoti);

		notificationDao.addNotification(notification);

		Notification notification2 = new Notification();
		notification2.setMemberId(memberId);
		LocalDate localDate2 = LocalDate.now();
		String localTime2 = LocalTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_TIME);

		notification2.setDate(localDate2.toString());
		notification2.setTime(localTime2);
		notification2.setMessage(orgNoti);
		notificationDao.addNotification(notification2);
		return 1;

	}

	// Genetate notification on New Policy Add//##
	@Override
	public int notifyOnPolicyAdd(Policy policy) {

		Member member = memberDao.getMember(policy.getMemberId());

		String orgNoti = "Dear " + member.getFirstName() + " Your policy with name " + policy.getPolicyName()
				+ " at  " + policy.getPolicyPlace() + " is Successfully added. ";

		Notification notification = new Notification();
		notification.setMemberId(policy.getMemberId());
		LocalDate localDate = LocalDate.now();
		String localTime = LocalTime.now().truncatedTo(ChronoUnit.SECONDS).format(DateTimeFormatter.ISO_LOCAL_TIME);
		notification.setDate(localDate.toString());
		notification.setTime(localTime);
		notification.setMessage(orgNoti);
		notificationDao.addNotification(notification);
		return 1;

	}

	// Get List of Notifications
	@Override
	public List<Notification> getNotifications(int memberId) {
		return notificationDao.getNotifications(memberId);
	}

	// Delete Notifications
	@Override
	public int deleteNotification(int notificationId) {
		return notificationDao.deleteNotification(notificationId);
	}

}
