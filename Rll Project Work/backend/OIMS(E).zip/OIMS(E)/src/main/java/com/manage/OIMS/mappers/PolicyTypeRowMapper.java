package com.manage.OIMS.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.manage.OIMS.model.PolicyType;

@Service
public class PolicyTypeRowMapper implements RowMapper<PolicyType> {

	@Override
	public PolicyType mapRow(ResultSet rs, int rowNum) throws SQLException {
		
       PolicyType policytype = new PolicyType();
		
       policytype.setPolicyTypeId(rs.getInt("policytype_id"));
       policytype.setPolicyTypeName(rs.getString("policytype_name"));
       policytype.setPolicyTypeCost(rs.getInt("policytype_cost"));
       policytype.setPolicyId(rs.getInt("policy_id"));
		
		
		return policytype;
		
	}

}
