package com.manage.OIMS.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.manage.OIMS.mappers.PolicyTypeRowMapper;
import com.manage.OIMS.model.PolicyType;

@Repository
public class PolicyTypeDaoImpl implements PolicyTypeDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	PolicyTypeRowMapper rowMapper;

	// Add policytype
	@Override
	public PolicyType addPolicyType(PolicyType policytype) {
		Object[] args = { policytype.getPolicyTypeName(), policytype.getPolicyTypeCost(), policytype.getPolicyId() };

		String query = "INSERT INTO policytype (policytype_name, policytype_cost, policy_id)" + "   VALUES (?,?,?)";

		this.jdbcTemplate.update(query, args);
		return policytype;
	}

	// Update PolicyType
	@Override
	public int updatePolicyType(PolicyType policytype) {
		String query = "update policytype set policytype_name=?, policytype_cost=? where policytype_id=? ";

		Object[] args = { policytype.getPolicyTypeName(), policytype.getPolicyTypeCost(), policytype.getPolicyTypeId() };

		return this.jdbcTemplate.update(query, args);
	}

	// Get PolicyType
	@Override
	public PolicyType getPolicyType(int policytypeId) {
		String query = "select * from policytype where policytype_id=?";

		return this.jdbcTemplate.queryForObject(query, rowMapper, policytypeId);
	}

	// Delete PolicyType
	@Override
	public int deletePolicyType(int policytypeId) {
		String query = "delete from policytype where policytype_id=?";
		Object[] args = { policytypeId };
		return this.jdbcTemplate.update(query, args);
	}

	// Delete PolicyType by Policy ID
	@Override
	public int deletePolicyTypeByPolicyId(int policyId) {
		String query = "delete from policytype where policy_id=?";
		return this.jdbcTemplate.update(query, policyId);
	}

	// Get policytype list by policy Id
	@Override
	public List<PolicyType> getPolicyTypesByPolicyId(int policyId) {
		String query = "select * from policytype where policy_id=?";
		return this.jdbcTemplate.query(query, rowMapper, policyId);
	}

	// Get policytype list by Name and Policy Id
	@Override
	public PolicyType getByNameAndPolicyId(String eName, int vId) {
		String query = "select * from policytype where policytype_name=? and policy_id=?";
		return this.jdbcTemplate.queryForObject(query, rowMapper, eName, vId);

	}

}
