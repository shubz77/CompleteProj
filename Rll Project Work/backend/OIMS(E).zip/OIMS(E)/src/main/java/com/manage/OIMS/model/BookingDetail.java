package com.manage.OIMS.model;

import java.sql.Date;

public class BookingDetail {
	
	private int policyId;
	
	private int memberId;
	
	private int bookingId;
	private Date date;
	private int guestCount;
	private String policytypeName;
	private int policytypeCost;
	private int equipmentCost;
	private int foodItemCost;
	private int totalCost;
	private String paymentStatus;
    	
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String email;
	
	private String policyName;
	private String policyPlace;
	private String policyContact;
	private int delStatus;
	
	
	
	
	
	public BookingDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BookingDetail(int policyId, int memberId, int bookingId, Date date, int guestCount, String policytypeName,
			String equipmentName, String foodItemName, int policytypeCost, int equipmentCost, int foodItemCost,
			int totalCost, String paymentStatus, String firstName, String lastName, String phoneNumber, String email,
			String policyName, String policyPlace, String policyContact, int delStatus) {
		super();
		this.policyId = policyId;
		this.memberId = memberId;
		this.bookingId = bookingId;
		this.date = date;
		this.guestCount = guestCount;
		this.policytypeName = policytypeName;
		//this.equipmentName = equipmentName;
		//this.foodItemName = foodItemName;
		this.policytypeCost = policytypeCost;
		this.equipmentCost = equipmentCost;
		this.foodItemCost = foodItemCost;
		this.totalCost = totalCost;
		this.paymentStatus = paymentStatus;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.email = email;
		this.policyName = policyName;
		this.policyPlace = policyPlace;
		this.policyContact = policyContact;
		this.delStatus = delStatus;
	}
	public int getDelStatus() {
		return delStatus;
	}
	public void setDelStatus(int delStatus) {
		this.delStatus = delStatus;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getGuestCount() {
		return guestCount;
	}
	public void setGuestCount(int guestCount) {
		this.guestCount = guestCount;
	}
	public String getPolicyTypeName() {
		return policytypeName;
	}
	public void setPolicyTypeName(String policytypeName) {
		this.policytypeName = policytypeName;
	}
	/*public String getEquipmentName() {
		return equipmentName;
	}
	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}
	public String getFoodItemName() {
		return foodItemName;
	}
	public void setFoodItemName(String foodItemName) {
		this.foodItemName = foodItemName;
	}*/
	public int getPolicyTypeCost() {
		return policytypeCost;
	}
	public void setPolicyTypeCost(int policytypeCost) {
		this.policytypeCost = policytypeCost;
	}
	public int getEquipmentCost() {
		return equipmentCost;
	}
	public void setEquipmentCost(int equipmentCost) {
		this.equipmentCost = equipmentCost;
	}
	public int getFoodItemCost() {
		return foodItemCost;
	}
	public void setFoodItemCost(int foodItemCost) {
		this.foodItemCost = foodItemCost;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public String getPolicyPlace() {
		return policyPlace;
	}
	public void setPolicyPlace(String policyPlace) {
		this.policyPlace = policyPlace;
	}
	public String getPolicyContact() {
		return policyContact;
	}
	public void setPolicyContact(String policyContact) {
		this.policyContact = policyContact;
	}
	@Override
	public String toString() {
		return "BookingDetail [policyId=" + policyId + ", memberId=" + memberId + ", bookingId=" + bookingId + ", date="
				+ date + ", guestCount=" + guestCount + ", policytypeName=" + policytypeName + ", policytypeCost=" + policytypeCost + ", equipmentCost=" + equipmentCost
				+ ", foodItemCost=" + foodItemCost + ", totalCost=" + totalCost + ", paymentStatus=" + paymentStatus
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", phoneNumber=" + phoneNumber + ", email="
				+ email + ", policyName=" + policyName + ", policyPlace=" + policyPlace + ", policyContact=" + policyContact
				+ "]";
	}
	
	
	
	

	

}
