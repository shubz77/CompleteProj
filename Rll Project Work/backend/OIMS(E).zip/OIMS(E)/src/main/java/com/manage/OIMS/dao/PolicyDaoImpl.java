package com.manage.OIMS.dao;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.manage.OIMS.mappers.PolicyRowMapper;
import com.manage.OIMS.model.Policy;

@Repository
public class PolicyDaoImpl implements PolicyDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	PolicyRowMapper rowMapper;

	// Method to get List of Policy By OrganizerId
	@Override
	public List<Policy> getPolicyByOrganizerId(int orgId) {
		String query = "select * from policy where member_id = ?";
		return this.jdbcTemplate.query(query, rowMapper, orgId);
	}

	// Method to get distinct places
	public List<String> getAllDistinctPlaces() {
		String query = "select distinct policy_place from policy";
		return this.jdbcTemplate.query(query, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString("policy_place");
			}
		});
	}

	// Method to get policy for selected place
	public List<Policy> getPolicyOfPlace(String place) {
		String query = "select * from policy where policy_place =?";
		return this.jdbcTemplate.query(query, rowMapper, place);
	}

	// Method to add Policy in database
	@Override
	public Policy addPolicy(Policy policy) {
		Object[] args = { policy.getPolicyName(), policy.getPolicyPlace(), policy.getPolicyContact(), policy.getMemberId() };
		String query = "INSERT INTO policy (policy_name,policy_place, policy_contact,member_id)" + "   VALUES (?,?,?,?)";
		this.jdbcTemplate.update(query, args);
		return policy;
	}

	// Method to Update Policy Details
	@Override
	public int updatePolicy(Policy policy) {
		String query = "update policy set policy_name=?, policy_place=?, policy_contact=? where policy_id=?";
		Object[] args = { policy.getPolicyName(), policy.getPolicyPlace(), policy.getPolicyContact(), policy.getPolicyId() };
		return this.jdbcTemplate.update(query, args);
	}

	// Method to get single policy
	@Override
	public Policy getPolicy(int policyId) {
		String query = "select * from policy where policy_id=?";
		return this.jdbcTemplate.queryForObject(query, rowMapper, policyId);
	}

	// List of All Policys
	@Override
	public List<Policy> getPolicys() {
		String query = "select * from policy";
		return this.jdbcTemplate.query(query, rowMapper);
	}

	// Delete Policy.
	@Override
	public int deletePolicy(int policyId) {
		String query = "delete from policy where policy_id=?";
		Object[] args = { policyId };
		return this.jdbcTemplate.update(query, args);

	}

}
