package com.manage.OIMS.dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.manage.OIMS.mappers.BookingDetailRowMapper;
import com.manage.OIMS.mappers.BookingRowMapper;
import com.manage.OIMS.model.Booking;
import com.manage.OIMS.model.BookingDetail;

@Repository
public class BookingDaoImpl implements BookingDao {

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	BookingRowMapper rowMapper;

	// Add booking
	@Override
	public Booking addBooking(Booking booking) {
		Object[] args = { booking.getBookingId(), booking.getDate(), booking.getGuestCount(), booking.getPolicyTypeName(),
				 booking.getPolicyTypeCost(),
				booking.getEquipmentCost(), booking.getFoodItemCost(), booking.getTotalCost(),
				booking.getPaymentStatus(), booking.getMemberId(), booking.getPolicyId(), booking.getDelStatus() };

		String query = "INSERT INTO booking (booking_id, date, policy_count, policytype_name, equipment_name, food_item_name,"
				+ " policytype_cost, misc_cost, other_cost, total_cost, payment_status, member_id, policy_id, del_status)"
				+ "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		this.jdbcTemplate.update(query, args);
		return booking;
	}

	// Get booking
	@Override
	public Booking getBooking(int bookingId) {
		String query = "select * from booking WHERE booking_id=?";
		System.out.println(bookingId);
		return this.jdbcTemplate.queryForObject(query, new BookingRowMapper(), bookingId);
	}

	// Get Booking Detail
	@Override
	public BookingDetail getSingleBooking(int bookingId) {
		String query = "select booking.member_id,booking.policy_id,booking.booking_id,booking.date,booking.policy_count,booking.policytype_name,"
				+ "booking.policytype_cost,booking.misc_cost,booking.other_cost,booking.total_cost,booking.payment_status,"
				+ "member.first_name,member.last_name,member.email,member.phone_number,"
				+ "policy.policy_name,policy.policy_place,policy.policy_contact,booking.del_status"
				+ " FROM booking INNER JOIN member ON member.member_id=booking.member_id"
				+ " INNER JOIN policy ON policy.policy_id=booking.policy_id" + " WHERE booking.booking_id=?";

		return this.jdbcTemplate.queryForObject(query, new BookingDetailRowMapper(), bookingId);
	}

	// Get List of Booking
	@Override
	public List<Booking> getBookings() {
		String query = "select * from booking";
		return this.jdbcTemplate.query(query, rowMapper);
	}

	// Get List of Booking DetailS
	@Override
	public List<BookingDetail> getBookingDetail() {
		String query = "select booking.member_id,booking.policy_id,booking.booking_id,booking.date,booking.policy_count,booking.policytype_name,"
				+ "booking.policytype_cost,booking.misc_cost,booking.other_cost,booking.total_cost,booking.payment_status,"
				+ "member.first_name,member.last_name,member.email,member.phone_number,"
				+ "policy.policy_name,policy.policy_place,policy.policy_contact,booking.del_status"
				+ " FROM booking INNER JOIN member ON member.member_id=booking.member_id"
				+ " INNER JOIN policy ON policy.policy_id=booking.policy_id";

		return this.jdbcTemplate.query(query, new BookingDetailRowMapper());

	}

	// Delete Booking
	@Override
	public int deleteBooking(int bookingId) {
		String query = "delete from booking where booking_id=?";
		return this.jdbcTemplate.update(query, bookingId);

	}

	// Get List of Booking Detail by User Id
	@Override
	public List<BookingDetail> getBookingsByUserId(int userId) {
		String query = "select booking.member_id,booking.policy_id,booking.booking_id,booking.date,booking.policy_count,booking.policytype_name,booking.equipment_name,"
				+ "booking.food_item_name,booking.policytype_cost,booking.misc_cost,booking.other_cost,booking.total_cost,booking.payment_status,"
				+ "member.first_name,member.last_name,member.email,member.phone_number,"
				+ "policy.policy_name,policy.policy_place,policy.policy_contact,booking.del_status"
				+ " FROM booking INNER JOIN member ON member.member_id=booking.member_id"
				+ " INNER JOIN policy ON policy.policy_id=booking.policy_id"
				+ " WHERE booking.member_id=? ORDER BY booking.date DESC ";

		return this.jdbcTemplate.query(query, new BookingDetailRowMapper(), userId);
	}

	// Update payment status
	@Override
	public int doPayment(int bookingId) {
		String query = "update booking set payment_status=?, del_status=? where booking_id= ?";
		Object[] args = { "Processed", 111, bookingId };
		return this.jdbcTemplate.update(query, args);
	}

	// Get List of Booking Detail by Policy Id
	@Override
	public List<BookingDetail> getBookingByPolicyId(int policyId) {
		String query = "select booking.member_id,booking.policy_id,booking.booking_id,booking.date,booking.policy_count,booking.policytype_name,"
				+ ",booking.policytype_cost,booking.misc_cost,booking.other_cost,booking.total_cost,booking.payment_status,"
				+ "member.first_name,member.last_name,member.email,member.phone_number,"
				+ "policy.policy_name,policy.policy_place,policy.policy_contact,booking.del_status"
				+ " FROM booking INNER JOIN member ON member.member_id=booking.member_id"
				+ " INNER JOIN policy ON policy.policy_id=booking.policy_id" + " WHERE booking.policy_id=?";

		return this.jdbcTemplate.query(query, new BookingDetailRowMapper(), policyId);
	}

	// List of Dates for Paid Bookings by Policy Id
	@Override
	public List<Date> getBookedDatesByPolicyId(int policyId) {
		String query = "select date from booking where policy_id = ? and payment_status=? order by date asc";
		return this.jdbcTemplate.query(query, new RowMapper<Date>() {
			public Date mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getDate("date");
			}
		}, policyId, "Processed");
	}

	
}


